import Link from "next/link";

const items = [
  ["Dashboard","/"],
  ["Agenda","/agenda"],
  ["Boekingen","/boekingen"],
  ["Financiën","/financien"],
  ["Documenten","/documenten"],
  ["Inventaris","/inventaris"],
  ["Bandleden","/bandleden"],
  ["Instellingen","/instellingen"]
];

export function Nav() {
  return <aside className="sidebar">
    <div className="brand">🎵 Rejoice</div>
    <nav className="nav">{items.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}</nav>
  </aside>;
}