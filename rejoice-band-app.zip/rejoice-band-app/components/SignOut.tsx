 "use client";
import { createClient } from "@/lib/supabase";
export function SignOut() {
  return <button className="btn secondary" onClick={async()=>{await createClient().auth.signOut(); location.href="/login";}}>Uitloggen</button>;
}