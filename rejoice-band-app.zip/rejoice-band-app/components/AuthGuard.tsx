 "use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [loading,setLoading] = useState(true);
  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getUser().then(({data}) => {
      if (!data.user) router.replace("/login");
      else setLoading(false);
    });
  }, [router]);
  if (loading) return <div className="empty">Laden…</div>;
  return <>{children}</>;
}