# Rejoice band app

Interne bandomgeving voor Rejoice.

## Benodigd
- Node.js 20+
- Een Supabase-project

## Lokaal starten

1. Kopieer `.env.example` naar `.env.local`
2. Vul je Supabase URL en publishable key in.
3. Voer `supabase/schema.sql` uit in Supabase SQL Editor.
4. Installeer dependencies:
   `npm install`
5. Start:
   `npm run dev`

## Supabase accounts

Maak de zeven gebruikers aan in Supabase Authentication. Gebruik de adressen `voornaam@wijzijnrejoice.nl`. Stel daarna per gebruiker een eerste wachtwoord in en laat ieder lid dat in Instellingen wijzigen.

## Belangrijk
De app bevat geen service-role key. Gebruik alleen de publishable key in `.env.local`.

## Productie
De app kan naar GitHub en vervolgens naar een Next.js-hostingdienst zoals Cloudflare Pages/Workers of een andere Next.js-host. Het gewenste domein is `app.wijzijnrejoice.nl`.
