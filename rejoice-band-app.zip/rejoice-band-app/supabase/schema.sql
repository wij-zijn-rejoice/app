-- REJOICE DATABASE
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references auth.users(id) on delete cascade,
  name text not null,
  email text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  photo_url text,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  start_time time,
  end_time time,
  client text not null,
  contact_person text,
  email text,
  phone text,
  location text,
  agreed_fee numeric(12,2),
  status text not null default 'Optie' check(status in ('Optie','Bevestigd','Afgerond','Geannuleerd')),
  notes text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  start_datetime timestamptz not null,
  end_datetime timestamptz not null,
  location text,
  booking_id uuid references public.bookings(id) on delete set null,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.financial_transactions (
  id uuid primary key default gen_random_uuid(),
  type text not null check(type in ('income','expense')),
  amount numeric(12,2) not null check(amount >= 0),
  date date not null default current_date,
  category text,
  description text,
  paid_by text,
  received_by text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text not null default 'Overig',
  storage_path text not null,
  original_filename text not null,
  uploaded_by uuid not null references auth.users(id),
  uploaded_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.inventory_items enable row level security;
alter table public.bookings enable row level security;
alter table public.calendar_events enable row level security;
alter table public.financial_transactions enable row level security;
alter table public.documents enable row level security;

create policy "members can read profiles" on public.profiles for select to authenticated using (true);
create policy "members can insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = user_id);
create policy "members can update own profile" on public.profiles for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "members can read inventory" on public.inventory_items for select to authenticated using (true);
create policy "members can insert inventory" on public.inventory_items for insert to authenticated with check (auth.uid() = owner_id);
create policy "members can update inventory" on public.inventory_items for update to authenticated using (true) with check (true);
create policy "members can delete inventory" on public.inventory_items for delete to authenticated using (true);

create policy "members can read bookings" on public.bookings for select to authenticated using (true);
create policy "members can insert bookings" on public.bookings for insert to authenticated with check (auth.uid() = created_by);
create policy "members can update bookings" on public.bookings for update to authenticated using (true) with check (true);
create policy "members can delete bookings" on public.bookings for delete to authenticated using (true);

create policy "members can read events" on public.calendar_events for select to authenticated using (true);
create policy "members can insert events" on public.calendar_events for insert to authenticated with check (auth.uid() = created_by);
create policy "members can update events" on public.calendar_events for update to authenticated using (true) with check (true);
create policy "members can delete events" on public.calendar_events for delete to authenticated using (true);

create policy "members can read finances" on public.financial_transactions for select to authenticated using (true);
create policy "members can insert finances" on public.financial_transactions for insert to authenticated with check (auth.uid() = created_by);
create policy "members can update finances" on public.financial_transactions for update to authenticated using (true) with check (true);
create policy "members can delete finances" on public.financial_transactions for delete to authenticated using (true);

create policy "members can read documents" on public.documents for select to authenticated using (true);
create policy "members can insert documents" on public.documents for insert to authenticated with check (auth.uid() = uploaded_by);
create policy "members can update documents" on public.documents for update to authenticated using (true) with check (true);
create policy "members can delete documents" on public.documents for delete to authenticated using (true);

-- Storage bucket for inventory photos.
insert into storage.buckets (id, name, public) values ('inventory','inventory',true)
on conflict (id) do nothing;

create policy "authenticated can upload inventory photos" on storage.objects for insert to authenticated with check (bucket_id='inventory');
create policy "authenticated can read inventory photos" on storage.objects for select to authenticated using (bucket_id='inventory');
create policy "authenticated can update inventory photos" on storage.objects for update to authenticated using (bucket_id='inventory');
create policy "authenticated can delete inventory photos" on storage.objects for delete to authenticated using (bucket_id='inventory');

-- Optional helper trigger: automatically create a profile after a new auth user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (user_id, name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)), new.email)
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
