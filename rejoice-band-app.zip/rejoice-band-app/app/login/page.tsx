 "use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase";
import { useRouter } from "next/navigation";

export default function Login() {
  const router=useRouter(); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
  async function submit(e:FormEvent){e.preventDefault();setBusy(true);setError(""); const {error}=await createClient().auth.signInWithPassword({email,password}); if(error)setError("Inloggen mislukt. Controleer e-mail en wachtwoord."); else router.replace("/"); setBusy(false);}
  return <div className="login"><form className="loginbox" onSubmit={submit}><h1>🎵 Rejoice</h1><p className="muted">Log in bij de bandomgeving.</p><label>E-mailadres</label><input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><label>Wachtwoord</label><input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} required/><div style={{height:16}}/>{error&&<p style={{color:"#b42318"}}>{error}</p>}<button className="btn" disabled={busy}>{busy?"Inloggen…":"Inloggen"}</button></form></div>;
}