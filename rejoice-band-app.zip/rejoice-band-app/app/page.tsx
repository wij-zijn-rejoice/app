import { AppShell } from "@/components/AppShell";
import { AuthGuard } from "@/components/AuthGuard";
import { SignOut } from "@/components/SignOut";

export default function Dashboard() {
 return <AuthGuard><AppShell><div className="topbar"><div><h1>Dashboard</h1><p className="muted">Welkom bij de Rejoise-bandomgeving.</p></div><SignOut/></div>
 <div className="grid"><div className="card"><div className="muted">Volgende boeking</div><div className="stat">—</div></div><div className="card"><div className="muted">Volgende afspraak</div><div className="stat">—</div></div><div className="card"><div className="muted">Saldo</div><div className="stat">€ 0,00</div></div><div className="card"><div className="muted">Inventaris</div><div className="stat">—</div></div></div>
 <div style={{height:16}}/><div className="card"><h2>Snel aan de slag</h2><p className="muted">Gebruik de navigatie om een boeking, afspraak, financiële transactie, document of inventarisitem toe te voegen.</p></div>
 </AppShell></AuthGuard>;
}