import "./globals.css";
import { Nav } from "@/components/Nav";

export const metadata = {
  title: "Rejoice",
  description: "Band management voor Rejoice"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}